"use strict";
exports.__esModule = true;
var aws_cloudformation_custom_resource_1 = require("aws-cloudformation-custom-resource");
var AWS = require("aws-sdk");
var athena = new AWS.Athena();
var log;
function NamedQuery(event, context, callback, logger) {
    log = logger;
    new aws_cloudformation_custom_resource_1.CustomResource(context, callback, logger)
        .onCreate(Create)
        .onUpdate(Update)
        .onDelete(Delete)
        .handle(event);
}
exports.NamedQuery = NamedQuery;
function Create(event) {
    return new Promise(function (resolve, reject) {
        createQuery(event.ResourceProperties)
            .then(function (id) {
            event.addResponseValue('id', id);
            event.setPhysicalResourceId(id);
            resolve(event);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function Update(event) {
    return new Promise(function (resolve, reject) {
        if (JSON.stringify(event.OldResourceProperties) ==
            JSON.stringify(event.ResourceProperties)) {
            log.info("No changes detected for NamedQuery " + event.ResourceProperties.Name + ". Not attempting any update");
            return resolve(event);
        }
        reject(new Error('Queries cannot be changed. Please create w new resource under a different name.'));
        //event.PhysicalResourceId = 'b47c5c28-0e6f-41f3-ae37-8488701c6340'; // TODO: remove this
        // Athena does not support updating queries. We delete && crate instead
        /* This does actually not work. when we return a different resource ID after re-creating. CFN will attempt to delete the old resource again.
        deleteQuery(event.PhysicalResourceId)
          .then(() => {
            createQuery(event.ResourceProperties)
              .then((id) => {
                event.addResponseValue('id', id);
                event.setPhysicalResourceId(id);
                resolve(event);
              })
              .catch((err) => {
                reject(err);
              });
          })
          .catch((err) => {
            reject(err);
          });
          */
    });
}
function Delete(event) {
    //event.PhysicalResourceId = 'b47c5c28-0e6f-41f3-ae37-8488701c6340'; // TODO: remove this
    return new Promise(function (resolve, reject) {
        deleteQuery(event.PhysicalResourceId)
            .then(function () {
            resolve(event);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function createQuery(resourceProperties) {
    log.info("Attempting to create Athena NamedQuery " + resourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var params = {
            Name: resourceProperties.Name,
            Database: resourceProperties.Database,
            QueryString: resourceProperties.QueryString
        };
        if (resourceProperties.Description.length) {
            params['Description'] = resourceProperties.Description;
        }
        if (resourceProperties.WorkGroup.length) {
            params['WorkGroup'] = resourceProperties.WorkGroup;
        }
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.createNamedQuery(params, function (err, data) {
            if (err)
                return reject(err);
            resolve(data.NamedQueryId);
        });
    });
}
function deleteQuery(queryId) {
    log.info("Attempting to delete Athena NamedQuery with ID" + queryId);
    return new Promise(function (resolve, reject) {
        var params = {
            NamedQueryId: queryId
        };
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.deleteNamedQuery(params, function (err, _) {
            if (err)
                return reject(err);
            resolve();
        });
    });
}
