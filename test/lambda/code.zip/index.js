"use strict";
exports.__esModule = true;
exports.handler = void 0;
var aws_cloudformation_custom_resource_1 = require("aws-cloudformation-custom-resource");
var athena_1 = require("./athena");
var logger = new aws_cloudformation_custom_resource_1.StandardLogger();
var handler = function (event, context, callback) {
    if (event === void 0) { event = {}; }
    logger.debug('Environment:', JSON.stringify(process.env, null, 2));
    switch (event.ResourceType.replace(/^Custom::DB-Migration-/, '')) {
        case 'Athena': {
            athena_1.Athena(event, context, callback, logger);
            break;
        }
        default: {
            callback("Unhandled resource type: " + event.ResourceType);
            break;
        }
    }
};
exports.handler = handler;
