"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
exports.__esModule = true;
exports.WorkGroup = void 0;
var aws_cloudformation_custom_resource_1 = require("aws-cloudformation-custom-resource");
var AWS = require("aws-sdk");
var athena = new AWS.Athena();
var log;
function WorkGroup(event, context, callback, logger) {
    log = logger;
    new aws_cloudformation_custom_resource_1.CustomResource(context, callback, logger)
        .onCreate(Create)
        .onUpdate(Update)
        .onDelete(Delete)
        .handle(event);
}
exports.WorkGroup = WorkGroup;
function Create(event) {
    log.info("Attempting to create Athena WorkGroup " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var params = {
            Name: event.ResourceProperties.Name,
            Description: event.ResourceProperties.Description,
            Configuration: {
                EnforceWorkGroupConfiguration: event.ResourceProperties.EnforceWorkGroupConfiguration == 'true',
                PublishCloudWatchMetricsEnabled: event.ResourceProperties.PublishCloudWatchMetricsEnabled == 'true',
                RequesterPaysEnabled: event.ResourceProperties.RequesterPaysEnabled == 'true'
            },
            Tags: makeTags(event, event.ResourceProperties)
        };
        if ('ResultConfiguration' in event.ResourceProperties) {
            params.Configuration['ResultConfiguration'] = capKeys(event.ResourceProperties.ResultConfiguration);
        }
        if ('BytesScannedCutoffPerQuery' in event.ResourceProperties) {
            params.Configuration['BytesScannedCutoffPerQuery'] = parseInt(event.ResourceProperties.BytesScannedCutoffPerQuery);
        }
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.createWorkGroup(params, function (err, _) {
            if (err)
                return reject(err);
            event.addResponseValue('ARN', event.ResourceProperties.Arn);
            resolve(event);
        });
    });
}
function Update(event) {
    return new Promise(function (resolve, reject) {
        updateWorkGroup(event)
            .then(updateWorkGroupAddTags)
            .then(updateWorkGroupRemoveTags)
            .then(function (data) {
            event.addResponseValue('ARN', event.ResourceProperties.Arn);
            resolve(data);
        })["catch"](function (err) {
            reject(err);
        });
    });
}
function getWorkGroup(name) {
    log.info("Fetching details of Athena WorkGroup " + name);
    return new Promise(function (resolve, reject) {
        var params = {
            WorkGroup: name
        };
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.getWorkGroup(params, function (err, data) {
            if (err)
                return reject(err);
            resolve(data);
        });
    });
}
function updateWorkGroup(event) {
    log.info("Attempting to update Athena WorkGroup " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        return __awaiter(this, void 0, void 0, function () {
            var current, err_1, params, hasOutputLocation, hasEncryptionConfiguration, hasBytesScannedCutoffPerQuery, resultConfig;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, , 3]);
                        return [4 /*yield*/, getWorkGroup(event.ResourceProperties.Name)];
                    case 1:
                        current = _a.sent();
                        return [3 /*break*/, 3];
                    case 2:
                        err_1 = _a.sent();
                        reject("Unable to get WorkGroup of name " + event.ResourceProperties.Name + ": " + err_1);
                        return [3 /*break*/, 3];
                    case 3:
                        log.debug('Current WorkGroup', JSON.stringify(current, null, 2));
                        params = {
                            WorkGroup: event.ResourceProperties.Name,
                            Description: event.ResourceProperties.Description,
                            ConfigurationUpdates: {
                                EnforceWorkGroupConfiguration: event.ResourceProperties.EnforceWorkGroupConfiguration == 'true',
                                PublishCloudWatchMetricsEnabled: event.ResourceProperties.PublishCloudWatchMetricsEnabled == 'true',
                                RequesterPaysEnabled: event.ResourceProperties.RequesterPaysEnabled == 'true'
                            }
                        };
                        hasOutputLocation = 'OutputLocation' in current.WorkGroup.Configuration.ResultConfiguration;
                        hasEncryptionConfiguration = 'EncryptionConfiguration' in
                            current.WorkGroup.Configuration.ResultConfiguration;
                        hasBytesScannedCutoffPerQuery = 'BytesScannedCutoffPerQuery' in current.WorkGroup.Configuration;
                        if ('BytesScannedCutoffPerQuery' in event.ResourceProperties) {
                            params.ConfigurationUpdates['BytesScannedCutoffPerQuery'] = parseInt(event.ResourceProperties.BytesScannedCutoffPerQuery);
                        }
                        else if (hasBytesScannedCutoffPerQuery &&
                            !('BytesScannedCutoffPerQuery' in event.ResourceProperties)) {
                            params.ConfigurationUpdates['RemoveBytesScannedCutoffPerQuery'] = true;
                        }
                        resultConfig = {};
                        if ('ResultConfiguration' in event.ResourceProperties) {
                            resultConfig = capKeys(event.ResourceProperties.ResultConfiguration);
                        }
                        if (hasEncryptionConfiguration &&
                            !('EncryptionConfiguration' in resultConfig)) {
                            resultConfig['RemoveEncryptionConfiguration'] = true;
                        }
                        if (hasOutputLocation && !('OutputLocation' in resultConfig)) {
                            resultConfig['RemoveOutputLocation'] = true;
                        }
                        if (Object.keys(resultConfig).length) {
                            params.ConfigurationUpdates['ResultConfigurationUpdates'] = resultConfig;
                        }
                        log.debug('Sending payload', JSON.stringify(params, null, 2));
                        athena.updateWorkGroup(params, function (err, _) {
                            if (err)
                                return reject(err);
                            resolve(event);
                        });
                        return [2 /*return*/];
                }
            });
        });
    });
}
function updateWorkGroupAddTags(event) {
    log.info("Attempting to update tags for Athena WorkGroup " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags)) {
            log.info("No changes of tags detected for WorkGroup " + event.ResourceProperties.Name + ". Not attempting any update");
            return resolve(event);
        }
        var params = {
            ResourceARN: event.ResourceProperties.Arn,
            Tags: newTags
        };
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.tagResource(params, function (err, _) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function updateWorkGroupRemoveTags(event) {
    log.info("Attempting to remove some tags for Athena WorkGroup " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        resolve(event);
        var oldTags = makeTags(event, event.OldResourceProperties);
        var newTags = makeTags(event, event.ResourceProperties);
        var tagsToRemove = getMissingTags(oldTags, newTags);
        if (JSON.stringify(oldTags) == JSON.stringify(newTags) ||
            !tagsToRemove.length) {
            log.info("No changes of tags detected for document " + event.ResourceProperties.Name + ". Not attempting any update");
            return resolve(event);
        }
        log.info("Will remove the following tags: " + JSON.stringify(tagsToRemove));
        var params = {
            ResourceARN: event.ResourceProperties.Arn,
            TagKeys: tagsToRemove
        };
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.untagResource(params, function (err, _) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function Delete(event) {
    log.info("Attempting to delete Athena WorkGroup " + event.ResourceProperties.Name);
    return new Promise(function (resolve, reject) {
        var params = {
            WorkGroup: event.ResourceProperties.Name,
            RecursiveDeleteOption: false
        };
        log.debug('Sending payload', JSON.stringify(params, null, 2));
        athena.deleteWorkGroup(params, function (err, _) {
            if (err)
                return reject(err);
            resolve(event);
        });
    });
}
function makeTags(event, properties) {
    var tags = [
        {
            Key: 'aws-cloudformation:stack-id',
            Value: event.StackId
        },
        {
            Key: 'aws-cloudformation:stack-name',
            Value: properties.StackName
        },
        {
            Key: 'aws-cloudformation:logical-id',
            Value: event.LogicalResourceId
        },
    ];
    if ('Tags' in properties) {
        Object.keys(properties.Tags).forEach(function (key) {
            tags.push({
                Key: key,
                Value: properties.Tags[key]
            });
        });
    }
    return tags;
}
function getMissingTags(oldTags, newTags) {
    var missing = oldTags.filter(missingTags(newTags));
    return missing.map(function (tag) {
        return tag.Key;
    });
}
function missingTags(newTags) {
    return function (currentTag) {
        return (newTags.filter(function (newTag) {
            return newTag.Key == currentTag.Key;
        }).length == 0);
    };
}
function capKeys(input) {
    var output = {};
    for (var _i = 0, _a = Object.entries(input); _i < _a.length; _i++) {
        var _b = _a[_i], key = _b[0], value = _b[1];
        if (!!value && value.constructor === Object) {
            value = capKeys(value);
        }
        output[upperFirst(key)] = value;
    }
    return output;
}
function upperFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
